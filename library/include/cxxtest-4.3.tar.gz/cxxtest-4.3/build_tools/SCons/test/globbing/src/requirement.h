#ifndef REQUIREMENT_H
#define REQUIREMENT_H
/**
 * @file requirement.h
 * Prototype for the call_a_requirement() function.
 *
 * @author Gašper Ažman (GA), gasper.azman@gmail.com
 * @version 1.0
 * @since 2008-08-29 10:08:35 AM
 */

bool call_a_requirement();

#endif
