//
// CXXTEST_MAX_DUMP_SIZE is the maximum number of bytes to dump in TS_ASSERT_SAME_DATA
//

#define CXXTEST_MAX_DUMP_SIZE 20
