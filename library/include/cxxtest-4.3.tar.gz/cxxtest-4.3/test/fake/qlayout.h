// fake qlayout.h

class QVBoxLayout
{
public:
    QVBoxLayout(void *) {}
    void addWidget(void *) {}
};
